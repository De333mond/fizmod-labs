using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lab3 : MonoBehaviour
{
    [SerializeField] private float A; 
    [SerializeField] private float B; 
    [SerializeField] private float[] t; 
    // [SerializeField] private float t2; 
    // [SerializeField] private float t3; 


    void Start()
    {
        
    }

    void FixedUpdate()
    {
        
    }
}
